<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="form.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir dados</title>
</head>
<body>
<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['email'] = $_POST['email'];
    header('Location: session.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Formulário com seus dados</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Inserir os Dados</h1>
    <form method="POST" action="">
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="senha">Senha</label>
        <input type="senha" id="senha" name="senha"><br><br>

        <input type="submit" value="Salvar">

    </form>
</body>
</html>