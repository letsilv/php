<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="session.css">
    <title>Atividade pratica</title>
</head>
<body>
<?php
session_start();

if (!isset($_SESSION['name']) || !isset($_SESSION['email'])) {
    header('Location: form.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sessão</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Resultado do Formulário</h1>
    <p><strong>Nome:</strong> <?php echo $_SESSION['name']; ?></p>
    <p><strong>Email:</strong> <?php echo $_SESSION['email']; ?></p>
    <a href="formulario.php" class="button">Sair</a>
</body>
</html>
